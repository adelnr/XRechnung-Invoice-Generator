<?php
/*
Plugin Name: ZUGFERD & XRechnung Invoice Generator
Description: Generates hybrid e-invoices (PDF + XML) compliant with ZUGFERD 2.9 and XRechnung standards.
Version: 2.9.1
Author: Adel Alrahmani
Text Domain: xrechnung
Requires PHP: 7.4
*/

defined('ABSPATH') || exit;

// Define plugin constants
define('XR_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('XR_PLUGIN_URL', plugin_dir_url(__FILE__));
// CRITICAL: Ensure this path is correct. It should point to dompdf/autoload.inc.php within your plugin.
define('XR_DOMPDF_AUTOLOAD', XR_PLUGIN_DIR . 'dompdf/autoload.inc.php');

// Check PHP version
if (version_compare(PHP_VERSION, '7.4', '<')) {
    add_action('admin_notices', function() {
        echo '<div class="error"><p>ZUGFeRD & XRechnung Invoice Generator requires PHP 7.4 or higher. Your current PHP version is '.PHP_VERSION.'. Please upgrade.</p></div>';
    });
    return;
}

// Check if dompdf autoload file exists AND include it
if (file_exists(XR_DOMPDF_AUTOLOAD)) {
    require_once XR_DOMPDF_AUTOLOAD; // THIS IS THE KEY LINE
} else {
    // If Dompdf is missing, stop everything and notify the admin.
    // This error message should appear if the path is wrong or the file is missing.
    add_action('admin_notices', function() {
        $dompdf_path_notice = XR_PLUGIN_DIR . 'dompdf/'; // Path to the folder
        echo '<div class="error"><p><strong>ZUGFeRD & XRechnung Invoice Generator Error:</strong> Dompdf library not found or autoload.inc.php is missing. Please ensure the <code>dompdf</code> folder is correctly installed in the plugin directory: <code>' . esc_html($dompdf_path_notice) . '</code>. Expected autoloader at: <code>' . esc_html(XR_DOMPDF_AUTOLOAD) . '</code></p></div>';
    });
    // Optionally, you might want to prevent further plugin loading if Dompdf is critical.
    // For example, by not including the other plugin files.
    // However, the admin notice is usually sufficient.
    // If the plugin tries to generate a PDF without Dompdf, it will fatal error anyway.
    // return; // Uncomment this if you want to completely stop the plugin if dompdf is missing.
}

// Include plugin files AFTER Dompdf autoloader (if it exists)
require_once XR_PLUGIN_DIR . 'includes/activation.php';
require_once XR_PLUGIN_DIR . 'includes/settings.php';
require_once XR_PLUGIN_DIR . 'includes/functions.php'; // This file uses Dompdf
require_once XR_PLUGIN_DIR . 'includes/form-handler.php';
require_once XR_PLUGIN_DIR . 'includes/shortcodes.php';

// ... rest of your main plugin file (activation hook, enqueue scripts, etc.) ...
// ... (Make sure the enqueue function from the previous step is also in here) ...

// Enqueue scripts and styles
function xr_enqueue_scripts() {
    $plugin_version = '2.9.1'; // Use the plugin's version for assets

    // Frontend form assets
    $css_file_path = XR_PLUGIN_DIR . 'assets/css/invoice-form.css';
    $js_file_path = XR_PLUGIN_DIR . 'assets/js/invoice-form.js';

    if (file_exists($css_file_path)) {
        wp_enqueue_style('xr-invoice-form-css', XR_PLUGIN_URL . 'assets/css/invoice-form.css', array(), $plugin_version);
    } else {
        error_log('XRechnung Plugin: CSS file not found at ' . $css_file_path);
    }

    if (file_exists($js_file_path)) {
        wp_enqueue_script('xr-invoice-form-js', XR_PLUGIN_URL . 'assets/js/invoice-form.js', array('jquery'), $plugin_version, true);

        wp_localize_script('xr-invoice-form-js', 'xr_invoice_form_data', array(
            'vat_rate' => (float) get_option('xrechnung_vat_rate', 0),
            'currency_code' => get_option('xrechnung_currency_code', 'EUR'),
            'columns' => get_option('xrechnung_columns', [
                ['key' => 'description', 'title' => __('Description', 'xrechnung'), 'required' => true],
                ['key' => 'quantity', 'title' => __('Quantity', 'xrechnung'), 'required' => true],
                ['key' => 'price', 'title' => __('Unit Price', 'xrechnung'), 'required' => true]
            ]),
            'text_remove_item' => __('Remove Item', 'xrechnung'),
            'text_subtotal' => __('Subtotal', 'xrechnung'),
            'text_vat' => __('VAT', 'xrechnung'),
            'text_grand_total' => __('Grand Total', 'xrechnung'),
        ));
    } else {
        error_log('XRechnung Plugin: JS file not found at ' . $js_file_path);
    }


    // Admin settings assets
    if (is_admin()) {
        $screen = get_current_screen();
        if ($screen && isset($screen->id) && $screen->id === 'settings_page_xrechnung-settings') {
            wp_enqueue_media();
            wp_enqueue_style('xr-admin-settings-css', XR_PLUGIN_URL . 'assets/css/admin-settings.css', array(), $plugin_version);
            wp_enqueue_script('xr-admin-settings-js', XR_PLUGIN_URL . 'assets/js/admin-settings.js', array('jquery'), $plugin_version, true);
        }
    }
}
add_action('wp_enqueue_scripts', 'xr_enqueue_scripts');
add_action('admin_enqueue_scripts', 'xr_enqueue_scripts');

// Activation hook
register_activation_hook(__FILE__, 'xr_activate_plugin');

// Initialize shortcode
add_action('init', 'xr_register_shortcodes');

// Load plugin textdomain for translations
function xr_load_textdomain() {
    load_plugin_textdomain('xrechnung', false, dirname(plugin_basename(__FILE__)) . '/languages/');
}
add_action('plugins_loaded', 'xr_load_textdomain');