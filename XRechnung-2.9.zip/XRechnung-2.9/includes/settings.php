<?php
defined('ABSPATH') || exit;

// Register settings page
add_action('admin_menu', 'xr_register_settings_page');

function xr_register_settings_page() {
    add_options_page(
        __('XRechnung Settings', 'xrechnung'),
        __('Invoice Settings', 'xrechnung'),
        'manage_options',
        'xrechnung-settings',
        'xr_settings_page_callback'
    );
}

// Initialize settings
add_action('admin_init', 'xr_register_plugin_settings');

function xr_register_plugin_settings() {
    $settings_group = 'xrechnung_settings_group';

    // Register settings
    register_setting($settings_group, 'xrechnung_logo', 'xr_sanitize_logo_url');
    register_setting($settings_group, 'xrechnung_company_name', 'sanitize_text_field');
    register_setting($settings_group, 'xrechnung_company_address', 'sanitize_textarea_field');
    register_setting($settings_group, 'xrechnung_company_phone', 'sanitize_text_field');
    register_setting($settings_group, 'xrechnung_company_email', 'sanitize_email');
    register_setting($settings_group, 'xrechnung_iban', 'sanitize_text_field');
    register_setting($settings_group, 'xrechnung_bic', 'sanitize_text_field');
    register_setting($settings_group, 'xrechnung_columns', 'xr_sanitize_columns_array');
    register_setting($settings_group, 'xrechnung_language', 'sanitize_text_field');
    register_setting($settings_group, 'xrechnung_intro_text', 'sanitize_textarea_field');
    register_setting($settings_group, 'xrechnung_footer_text', 'sanitize_textarea_field');
    register_setting($settings_group, 'xrechnung_signature_name', 'sanitize_text_field');
    register_setting($settings_group, 'xrechnung_signature_title', 'sanitize_text_field');
    register_setting($settings_group, 'xrechnung_signature_image', 'xr_sanitize_image_url');
    register_setting($settings_group, 'xrechnung_bank_info_type', 'sanitize_text_field');
    register_setting($settings_group, 'xrechnung_service_date', 'sanitize_text_field');
    // New settings
    register_setting($settings_group, 'xrechnung_next_invoice_number', 'absint');
    register_setting($settings_group, 'xrechnung_vat_rate', 'floatval');
    register_setting($settings_group, 'xrechnung_currency_code', 'sanitize_text_field');
    register_setting($settings_group, 'xrechnung_send_email_to_customer', 'absint'); // 1 for yes, 0 for no


    // Sections
    $sections = [
        'general' => __('General Settings', 'xrechnung'),
        'invoice_details' => __('Invoice Details & Numbering', 'xrechnung'),
        'columns' => __('Invoice Columns', 'xrechnung'),
        'text' => __('Invoice Texts', 'xrechnung'),
        'signature' => __('Signature Settings', 'xrechnung'),
        'bank' => __('Bank Information', 'xrechnung'),
    ];

    foreach ($sections as $id => $title) {
        add_settings_section(
            "xrechnung_{$id}_section",
            $title,
            "xr_{$id}_section_callback",
            'xrechnung-settings'
        );
    }

    // Fields
    $fields = [
        // General Section
        'general' => [
            ['id' => 'xrechnung_logo', 'title' => __('Company Logo', 'xrechnung'), 'callback' => 'xr_logo_input_callback'],
            ['id' => 'xrechnung_company_name', 'title' => __('Company Name', 'xrechnung'), 'callback' => 'xr_text_input_callback', 'args' => ['id' => 'xrechnung_company_name']],
            ['id' => 'xrechnung_company_address', 'title' => __('Company Address', 'xrechnung'), 'callback' => 'xr_textarea_input_callback', 'args' => ['id' => 'xrechnung_company_address']],
            ['id' => 'xrechnung_company_phone', 'title' => __('Company Phone', 'xrechnung'), 'callback' => 'xr_text_input_callback', 'args' => ['id' => 'xrechnung_company_phone', 'type' => 'tel']],
            ['id' => 'xrechnung_company_email', 'title' => __('Company Email', 'xrechnung'), 'callback' => 'xr_text_input_callback', 'args' => ['id' => 'xrechnung_company_email', 'type' => 'email']],
        ],
        // Invoice Details Section
        'invoice_details' => [
            ['id' => 'xrechnung_next_invoice_number', 'title' => __('Next Invoice Number', 'xrechnung'), 'callback' => 'xr_text_input_callback', 'args' => ['id' => 'xrechnung_next_invoice_number', 'type' => 'number', 'desc' => __('The plugin will use this number for the next invoice and then increment it.', 'xrechnung')]],
            ['id' => 'xrechnung_vat_rate', 'title' => __('VAT Rate (%)', 'xrechnung'), 'callback' => 'xr_text_input_callback', 'args' => ['id' => 'xrechnung_vat_rate', 'type' => 'number', 'step' => '0.01', 'desc' => __('Enter VAT rate, e.g., 19 for 19%.', 'xrechnung')]],
            ['id' => 'xrechnung_currency_code', 'title' => __('Currency Code', 'xrechnung'), 'callback' => 'xr_text_input_callback', 'args' => ['id' => 'xrechnung_currency_code', 'default' => 'EUR', 'desc' => __('E.g., EUR, USD. Ensure this matches your bank and payment processor.', 'xrechnung')]],
            ['id' => 'xrechnung_service_date', 'title' => __('Default Service Date (YYYY-MM-DD)', 'xrechnung'), 'callback' => 'xr_text_input_callback', 'args' => ['id' => 'xrechnung_service_date', 'type' => 'date', 'desc' => __('Optional. Can be overridden per invoice.', 'xrechnung')]],
            // Inside 'invoice_details' array for fields
            ['id' => 'xrechnung_send_email_to_customer','title' => __('Automatically Email Customer?', 'xrechnung'),'callback' => 'xr_checkbox_input_callback','args' => ['id' => 'xrechnung_send_email_to_customer','desc' => __('If checked, the generated invoice (ZIP) will be emailed to the customer.', 'xrechnung')]],
        ],
        // Columns Section
        'columns' => [
            ['id' => 'xrechnung_columns', 'title' => __('Invoice Columns', 'xrechnung'), 'callback' => 'xr_columns_input_callback'],
        ],
        // Text Section
        'text' => [
            ['id' => 'xrechnung_language', 'title' => __('Invoice Language', 'xrechnung'), 'callback' => 'xr_language_input_callback', 'args' => ['id' => 'xrechnung_language', 'desc' => __('Use 2-letter language code (e.g., en, de).', 'xrechnung')]],
            ['id' => 'xrechnung_intro_text', 'title' => __('Introduction Text (PDF)', 'xrechnung'), 'callback' => 'xr_textarea_input_callback', 'args' => ['id' => 'xrechnung_intro_text']],
            ['id' => 'xrechnung_footer_text', 'title' => __('Footer Text (PDF)', 'xrechnung'), 'callback' => 'xr_textarea_input_callback', 'args' => ['id' => 'xrechnung_footer_text']],
        ],
        // Signature Section
        'signature' => [
            ['id' => 'xrechnung_signature_name', 'title' => __('Signature Name', 'xrechnung'), 'callback' => 'xr_text_input_callback', 'args' => ['id' => 'xrechnung_signature_name']],
            ['id' => 'xrechnung_signature_title', 'title' => __('Signature Title', 'xrechnung'), 'callback' => 'xr_text_input_callback', 'args' => ['id' => 'xrechnung_signature_title']],
            ['id' => 'xrechnung_signature_image', 'title' => __('E-Signature Image', 'xrechnung'), 'callback' => 'xr_signature_image_input_callback'],
        ],
        // Bank Section
        'bank' => [
            ['id' => 'xrechnung_iban', 'title' => __('IBAN', 'xrechnung'), 'callback' => 'xr_text_input_callback', 'args' => ['id' => 'xrechnung_iban']],
            ['id' => 'xrechnung_bic', 'title' => __('BIC', 'xrechnung'), 'callback' => 'xr_text_input_callback', 'args' => ['id' => 'xrechnung_bic']],
            ['id' => 'xrechnung_bank_info_type', 'title' => __('Bank Information Type (PDF)', 'xrechnung'), 'callback' => 'xr_bank_info_type_input_callback'],
        ],
    ];

    foreach ($fields as $section_id => $field_list) {
        foreach ($field_list as $field) {
            add_settings_field(
                $field['id'],
                $field['title'],
                $field['callback'],
                'xrechnung-settings',
                "xrechnung_{$section_id}_section",
                isset($field['args']) ? $field['args'] : []
            );
        }
    }
}

// Section callbacks
function xr_general_section_callback() { echo '<p>' . __('Enter your company information here.', 'xrechnung') . '</p>'; }
function xr_invoice_details_section_callback() { echo '<p>' . __('Configure core invoice details, numbering, and financial settings.', 'xrechnung') . '</p>'; }
function xr_columns_section_callback() { echo '<p>' . __('Configure your invoice item columns here.', 'xrechnung') . '</p>'; }
function xr_text_section_callback() { echo '<p>' . __('Customize the text content of your invoices.', 'xrechnung') . '</p>'; }
function xr_signature_section_callback() { echo '<p>' . __('Add a signature to your invoices.', 'xrechnung') . '</p>'; }
function xr_bank_section_callback() { echo '<p>' . __('Choose how your bank information is displayed on the PDF.', 'xrechnung') . '</p>'; }


// Input field callbacks
function xr_text_input_callback($args) {
    $option_name = $args['id'];
    $value = get_option($option_name, isset($args['default']) ? $args['default'] : '');
    $type = isset($args['type']) ? $args['type'] : 'text';
    $step = isset($args['step']) ? 'step="' . esc_attr($args['step']) . '"' : '';
    $min = isset($args['min']) ? 'min="' . esc_attr($args['min']) . '"' : '';
    echo "<input type='{$type}' id='{$option_name}' name='{$option_name}' value='" . esc_attr($value) . "' class='regular-text' {$step} {$min}>";
    if (isset($args['desc'])) {
        echo "<p class='description'>" . esc_html($args['desc']) . "</p>";
    }
}

function xr_textarea_input_callback($args) {
    $option_name = $args['id'];
    $value = get_option($option_name, '');
    echo "<textarea id='{$option_name}' name='{$option_name}' class='regular-text' rows='4'>" . esc_textarea($value) . "</textarea>";
    if (isset($args['desc'])) {
        echo "<p class='description'>" . esc_html($args['desc']) . "</p>";
    }
}

function xr_logo_input_callback() {
    $option_name = 'xrechnung_logo';
    $logo_url = get_option($option_name);
    ?>
    <input type="text" id="<?php echo $option_name; ?>" name="<?php echo $option_name; ?>" value="<?php echo esc_attr($logo_url); ?>" class="regular-text">
    <input type="button" class="button button-secondary" value="<?php _e('Upload Logo', 'xrechnung'); ?>" id="upload_logo_button">
    <div id="logo_preview_wrapper" style="margin-top:10px;">
        <?php if ($logo_url): ?>
            <img src="<?php echo esc_url($logo_url); ?>" style="max-width:200px; max-height:100px; border:1px solid #ddd;">
        <?php endif; ?>
    </div>
    <?php
}

function xr_signature_image_input_callback() {
    $option_name = 'xrechnung_signature_image';
    $image_url = get_option($option_name);
    ?>
    <input type="text" id="<?php echo $option_name; ?>" name="<?php echo $option_name; ?>" value="<?php echo esc_attr($image_url); ?>" class="regular-text">
    <input type="button" class="button button-secondary" value="<?php _e('Upload Signature', 'xrechnung'); ?>" id="upload_signature_button">
     <div id="signature_preview_wrapper" style="margin-top:10px;">
        <?php if ($image_url): ?>
            <img src="<?php echo esc_url($image_url); ?>" style="max-width:200px; max-height:100px; border:1px solid #ddd;">
        <?php endif; ?>
    </div>
    <?php
}

function xr_columns_input_callback() {
    $columns = get_option('xrechnung_columns', [['key' => 'description', 'title' => 'Description', 'required' => true]]); // Default
    ?>
    <div id="invoice-columns-container">
        <?php if (!empty($columns)): ?>
            <?php foreach ($columns as $index => $column): ?>
            <div class="column-row" data-index="<?php echo $index; ?>">
                <input type="text"
                       name="xrechnung_columns[<?php echo $index; ?>][key]"
                       value="<?php echo esc_attr($column['key']); ?>"
                       placeholder="<?php _e('Key (no spaces, e.g., item_sku)', 'xrechnung'); ?>" required>
                <input type="text"
                       name="xrechnung_columns[<?php echo $index; ?>][title]"
                       value="<?php echo esc_attr($column['title']); ?>"
                       placeholder="<?php _e('Title (e.g., Item SKU)', 'xrechnung'); ?>" required>
                <label>
                    <input type="checkbox"
                           name="xrechnung_columns[<?php echo $index; ?>][required]"
                           value="1" <?php checked(isset($column['required']) && $column['required']); ?>>
                    <?php _e('Required?', 'xrechnung'); ?>
                </label>
                <button type="button" class="button button-secondary remove-column"><?php _e('Remove', 'xrechnung'); ?></button>
            </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
    <button type="button" class="button button-primary" id="add-column"><?php _e('Add New Column', 'xrechnung'); ?></button>
    <p class="description"><?php _e('Define the columns for invoice items. "description", "quantity", and "price" are commonly used keys.', 'xrechnung');?></p>
    <?php
}

function xr_language_input_callback($args) {
    $option_name = $args['id'];
    $value = get_option($option_name, 'en');
    $languages = ['en' => 'English', 'de' => 'Deutsch']; // Add more as needed
    echo "<select id='{$option_name}' name='{$option_name}'>";
    foreach ($languages as $code => $name) {
        echo "<option value='" . esc_attr($code) . "' " . selected($value, $code, false) . ">" . esc_html($name) . "</option>";
    }
    echo "</select>";
    if (isset($args['desc'])) {
        echo "<p class='description'>" . esc_html($args['desc']) . "</p>";
    }
}

function xr_bank_info_type_input_callback() {
    $value = get_option('xrechnung_bank_info_type', 'text');
    ?>
    <select name="xrechnung_bank_info_type">
        <option value="text" <?php selected($value, 'text'); ?>><?php _e('Text (IBAN/BIC)', 'xrechnung'); ?></option>
        <option value="qr" <?php selected($value, 'qr'); ?>><?php _e('QR Code (EPC QR)', 'xrechnung'); ?></option>
    </select>
    <?php
}

function xr_checkbox_input_callback($args) {
    $option_name = $args['id'];
    $value = get_option($option_name, 1); // Default to checked (send email)
    echo "<input type='checkbox' id='{$option_name}' name='{$option_name}' value='1' " . checked(1, $value, false) . ">";
    if (isset($args['desc'])) {
        echo "<label for='{$option_name}' style='margin-left: 5px;'>" . esc_html($args['desc']) . "</label>";
    }
}

// Sanitization functions
function xr_sanitize_logo_url($url) { return esc_url_raw(trim($url)); }
function xr_sanitize_image_url($url) { return esc_url_raw(trim($url)); }

function xr_sanitize_columns_array($columns) {
    if (!is_array($columns)) {
        return [];
    }
    $sanitized = [];
    foreach ($columns as $column) {
        if (isset($column['key']) && isset($column['title'])) {
            $sanitized[] = [
                'key' => sanitize_key($column['key']),
                'title' => sanitize_text_field($column['title']),
                'required' => isset($column['required']) ? true : false,
            ];
        }
    }
    return $sanitized;
}

// Settings page display
function xr_settings_page_callback() {
    if (!current_user_can('manage_options')) {
        return;
    }
    if (isset($_GET['settings-updated'])) {
        add_settings_error('xrechnung_messages', 'xrechnung_message', __('Settings Saved', 'xrechnung'), 'updated');
    }
    settings_errors('xrechnung_messages');
    ?>
    <div class="wrap xr-settings-wrap">
        <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
        <form action="options.php" method="post">
            <?php
            settings_fields('xrechnung_settings_group');
            do_settings_sections('xrechnung-settings');
            submit_button(__('Save Settings', 'xrechnung'));
            ?>
        </form>
    </div>
    <?php
}