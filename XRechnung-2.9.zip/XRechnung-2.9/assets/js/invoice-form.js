jQuery(document).ready(function($) {
    const itemsContainer = $('#xr-items-container');
    const vatRate = parseFloat(xr_invoice_form_data.vat_rate) || 0;
    const currencyCode = xr_invoice_form_data.currency_code || 'EUR';
    const columnsConfig = xr_invoice_form_data.columns || [];

    // Update VAT rate display
    $('#xr-vat-rate-display').text(vatRate.toFixed(2));

    function calculateTotals() {
        let subtotal = 0;
        itemsContainer.find('.xr-item-row').each(function() {
            const row = $(this);
            const quantityInput = row.find('input[name*="[quantity]"]');
            const priceInput = row.find('input[name*="[price]"]');

            const quantity = parseFloat(quantityInput.val().replace(',', '.')) || 0;
            const price = parseFloat(priceInput.val().replace(',', '.')) || 0;
            
            if (!isNaN(quantity) && !isNaN(price)) {
                subtotal += quantity * price;
            }
        });

        const vatAmount = subtotal * (vatRate / 100);
        const grandTotal = subtotal + vatAmount;

        $('#xr-subtotal-amount').text(subtotal.toFixed(2));
        $('#xr-vat-amount').text(vatAmount.toFixed(2));
        $('#xr-grand-total-amount').text(grandTotal.toFixed(2));
        $('#total_amount_incl_tax_calculated').val(grandTotal.toFixed(2)); // For potential server use
    }

    function updateItemRowIndexes() {
        itemsContainer.find('.xr-item-row').each(function(rowIndex) {
            $(this).find('input, select, textarea').each(function() {
                const currentName = $(this).attr('name');
                if (currentName) {
                    const newName = currentName.replace(/items\[\d+\]/, 'items[' + rowIndex + ']');
                    $(this).attr('name', newName);
                }
                const currentId = $(this).attr('id');
                 if (currentId) {
                    const newId = currentId.replace(/items_\d+_/, 'items_' + rowIndex + '_');
                    $(this).attr('id', newId);
                    // Update label 'for' attribute as well
                    $(this).closest('.xr-item-col').find('label').attr('for', newId);
                }
            });
        });
    }

    $('#xr-add-item').on('click', function() {
        const itemIndex = itemsContainer.find('.xr-item-row').length;
        const newRow = $('<div class="xr-item-row"></div>');

        columnsConfig.forEach(function(col) {
            const colDiv = $('<div class="xr-item-col xr-item-col-' + col.key + '"></div>');
            const label = $('<label for="items_' + itemIndex + '_' + col.key + '">' + col.title + (col.required ? ' <span class="required">*</span>' : '') + '</label>');
            const inputType = (col.key === 'price' || col.key === 'quantity') ? 'number' : 'text';
            const input = $('<input type="' + inputType + '" name="items[' + itemIndex + '][' + col.key + ']" id="items_' + itemIndex + '_' + col.key + '">');
            
            if (col.required) {
                input.attr('required', 'required');
            }
            if (inputType === 'number') {
                input.attr('step', '0.01').attr('min', '0');
            }
            colDiv.append(label).append(input);
            newRow.append(colDiv);
        });
        
        const removeButtonCol = $('<div class="xr-item-col xr-item-col-actions"></div>');
        const removeButton = $('<button type="button" class="button xr-remove-item" title="' + (xr_invoice_form_data.text_remove_item || 'Remove Item') + '">&times;</button>');
        removeButtonCol.append(removeButton);
        newRow.append(removeButtonCol);

        itemsContainer.append(newRow);
        updateItemRowIndexes(); // Not strictly necessary on add if itemIndex is managed well
        calculateTotals();
    });

    itemsContainer.on('click', '.xr-remove-item', function() {
        if (itemsContainer.find('.xr-item-row').length > 1) {
            $(this).closest('.xr-item-row').remove();
            updateItemRowIndexes();
            calculateTotals();
        } else {
            // Optionally clear the fields of the last row instead of removing
            $(this).closest('.xr-item-row').find('input').val('');
            calculateTotals();
            // alert('At least one item is required.');
        }
    });

    itemsContainer.on('input change', 'input[name*="[quantity]"], input[name*="[price]"]', function() {
        calculateTotals();
    });

    // Initial calculation on page load
    if (itemsContainer.find('.xr-item-row').length > 0) {
        calculateTotals();
    }

    // Trigger calculation for pre-filled forms (e.g. on error)
    if ($('#xr-invoice-form').length) {
        calculateTotals();
    }
});