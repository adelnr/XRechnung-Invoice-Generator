<?php
defined('ABSPATH') || exit;

function xr_handle_invoice_form_submission() {
    if (!isset($_POST['generate_invoice_submit'])) {
        return;
    }

    if (!isset($_POST['xr_invoice_form_nonce']) || !wp_verify_nonce($_POST['xr_invoice_form_nonce'], 'xr_generate_invoice_action')) {
        wp_die(__('Security check failed. Please try again.', 'xrechnung'));
    }

    $errors = [];
    $required_fields = [
        'customer_name' => __('Customer Name', 'xrechnung'),
        'customer_email' => __('Customer Email', 'xrechnung'), // Email also validated further
        'customer_address' => __('Customer Address', 'xrechnung'),
        'invoice_date' => __('Invoice Date', 'xrechnung'),
        'subject' => __('Subject', 'xrechnung'),
    ];

    $data = []; // To store sanitized form data

    // Sanitize and validate required fields
    foreach ($required_fields as $field_key => $label) {
        if (empty($_POST[$field_key])) {
            // Customer email is not strictly required if emails are disabled, but for general data integrity it's good to ask for it.
            // If you want to make email truly optional on the form even if emails are enabled, this logic needs adjustment.
            // For now, we assume it's required on the form, but sending depends on the setting.
            $errors[] = sprintf(__('%s is required.', 'xrechnung'), $label);
        } else {
            if ($field_key === 'customer_email') {
                $data[$field_key] = sanitize_email($_POST[$field_key]);
                if (!empty($_POST[$field_key]) && !is_email($data[$field_key])) { // Check if not empty before validating format
                     $errors[] = sprintf(__('%s is not a valid email address.', 'xrechnung'), $label);
                }
            } elseif ($field_key === 'invoice_date') {
                $data[$field_key] = sanitize_text_field($_POST[$field_key]);
                 if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $data[$field_key])) {
                    $errors[] = __('Invalid invoice date format (YYYY-MM-DD required).', 'xrechnung');
                }
            }
            else {
                $data[$field_key] = sanitize_text_field(stripslashes($_POST[$field_key]));
            }
        }
    }
    // If customer email was empty but passed the initial 'empty' check (e.g. spaces), sanitize_email might return empty.
    // We'll re-check for empty $data['customer_email'] before attempting to send an email.

    $items = [];
    $columns_config = get_option('xrechnung_columns', []);
    if (!empty($_POST['items']) && is_array($_POST['items'])) {
        foreach ($_POST['items'] as $index => $posted_item) {
            if (!is_array($posted_item)) {
                $errors[] = sprintf(__('Invalid item format in row %d.', 'xrechnung'), $index + 1);
                continue;
            }
            $current_item = [];
            $item_valid = true;
            foreach ($columns_config as $col_config) {
                $key = $col_config['key'];
                $value_raw = isset($posted_item[$key]) ? stripslashes($posted_item[$key]) : '';
                $value = sanitize_text_field($value_raw);

                if ($col_config['required'] && $value === '') { // Check against sanitized, trimmed value
                    $errors[] = sprintf(__('%s for item %d is required.', 'xrechnung'), __($col_config['title'], 'xrechnung'), $index + 1);
                    $item_valid = false;
                }

                if (($key === 'price' || $key === 'quantity')) {
                    if ($value !== '' && !is_numeric(str_replace(',', '.', $value_raw))) { // Validate raw numeric input
                         $errors[] = sprintf(__('%s for item %d must be a number.', 'xrechnung'), __($col_config['title'], 'xrechnung'), $index + 1);
                         $item_valid = false;
                    }
                    $current_item[$key] = ($value === '') ? 0 : (float)str_replace(',', '.', $value_raw); // Store as float or 0
                } else {
                    $current_item[$key] = $value;
                }
            }

            if($item_valid && isset($current_item['price']) && isset($current_item['quantity'])){
                 $items[] = $current_item;
            } else if ($item_valid && (!isset($current_item['price']) || !isset($current_item['quantity']))) {
                $errors[] = sprintf(__('Price and Quantity columns must be configured and values provided for item %d.', 'xrechnung'), $index + 1);
            }
        }
    }

    if (empty($items)) {
        $errors[] = __('At least one valid item is required.', 'xrechnung');
    }

    if (!empty($errors)) {
        set_transient('xr_invoice_form_errors', $errors, 60);
        global $xr_form_submission_errors; // For displaying immediately if no redirect occurs
        $xr_form_submission_errors = $errors;
        // If you always want to redirect back with errors:
        // wp_safe_redirect(wp_get_referer() ?: home_url()); exit;
        return; // Stop processing if there are errors
    }

    // All good, proceed with invoice generation
    try {
        $next_invoice_num_option = 'xrechnung_next_invoice_number';
        $current_invoice_number = (int) get_option($next_invoice_num_option, 1);
        // Consider invoice number prefix/suffix options in future if needed
        $new_invoice_id = str_pad($current_invoice_number, (int)get_option('xrechnung_invoice_number_padding', 3), '0', STR_PAD_LEFT);
        
        update_option($next_invoice_num_option, $current_invoice_number + 1);

        $total_amount_excl_tax = 0;
        foreach ($items as $item) {
            $total_amount_excl_tax += (float)$item['price'] * (float)$item['quantity'];
        }

        $vat_rate_percent = (float)get_option('xrechnung_vat_rate', 0);
        $vat_amount = $total_amount_excl_tax * ($vat_rate_percent / 100);
        $total_amount_incl_tax = $total_amount_excl_tax + $vat_amount;

        $data['items'] = $items;
        $data['total_amount_excl_tax'] = $total_amount_excl_tax;
        $data['vat_amount'] = $vat_amount;
        $data['total_amount_incl_tax'] = $total_amount_incl_tax;

        $upload_dir = wp_upload_dir();
        if (!xr_create_invoices_directory()) { // Ensure invoices directory exists
            throw new Exception(__('Failed to ensure invoices directory exists. Please check permissions on wp-content/uploads/.', 'xrechnung'));
        }

        $xml_content = xr_generate_invoice_xml($data, $new_invoice_id);
        if (!$xml_content) {
            throw new Exception(__('Failed to generate invoice XML.', 'xrechnung'));
        }
        $xml_file_path = $upload_dir['basedir'] . "/invoices/invoice_{$new_invoice_id}.xml";
        if(file_put_contents($xml_file_path, $xml_content) === false) {
             throw new Exception(sprintf(__('Failed to write XML file to: %s. Check server permissions.', 'xrechnung'), $xml_file_path));
        }

        $pdf_file_path = xr_generate_invoice_pdf($data, $new_invoice_id);
        if (!$pdf_file_path) { // xr_generate_invoice_pdf now returns false on failure
            throw new Exception(__('Failed to generate invoice PDF. Check PHP error log for Dompdf errors.', 'xrechnung'));
        }

        $zip_file_path = $upload_dir['basedir'] . "/invoices/invoice_{$new_invoice_id}.zip";
        $zip = new ZipArchive();
        if ($zip->open($zip_file_path, ZipArchive::CREATE | ZipArchive::OVERWRITE) === TRUE) {
            $zip->addFile($xml_file_path, "zugferd-invoice-{$new_invoice_id}.xml");
            $zip->addFile($pdf_file_path, "invoice_{$new_invoice_id}.pdf");
            $zip->close();
        } else {
            throw new Exception(__('Failed to create ZIP archive.', 'xrechnung'));
        }

        // --- Optional Email Sending ---
        $send_email_to_customer = (bool) get_option('xrechnung_send_email_to_customer', 1); // Default to true
        $customer_email_for_sending = isset($data['customer_email']) ? $data['customer_email'] : '';

        if ($send_email_to_customer) {
            if (!empty($customer_email_for_sending) && is_email($customer_email_for_sending)) {
                $company_name = get_option('xrechnung_company_name', __('Your Company', 'xrechnung'));

                $email_subject = sprintf(__('Invoice %s from %s', 'xrechnung'), $new_invoice_id, $company_name);
                
                $email_body = sprintf(__('Dear %s,', 'xrechnung'), $data['customer_name']) . "\n\n";
                $email_body .= sprintf(__('Please find attached your invoice %s.', 'xrechnung'), $new_invoice_id) . "\n\n";
                
                $pdf_intro_text = get_option('xrechnung_intro_text', ''); // Get intro text for PDF
                if(!empty($pdf_intro_text)){
                     $email_body .= wp_strip_all_tags($pdf_intro_text) . "\n\n"; // Use stripped tags for plain text email
                }
                
                $email_body .= __('Thank you for your business.', 'xrechnung') . "\n\n";
                $email_body .= sprintf(__('Kind regards,', 'xrechnung')) . "\n" . $company_name;

                $headers = ['Content-Type: text/plain; charset=UTF-8'];
                $attachments = [$zip_file_path];

                if (!wp_mail($customer_email_for_sending, $email_subject, $email_body, $headers, $attachments)) {
                    error_log("XRechnung Plugin: Failed to send invoice email to " . $customer_email_for_sending . " for invoice " . $new_invoice_id . ". Check mail server configuration.");
                    // Set a transient to inform user that email might have failed, but invoice was generated.
                    set_transient('xr_invoice_email_failed_' . $new_invoice_id, true, 300);
                } else {
                    // Optional: Add a notice that email was sent successfully
                    set_transient('xr_invoice_email_sent_' . $new_invoice_id, true, 300);
                }
            } else {
                error_log("XRechnung Plugin: Email sending enabled, but customer email address is missing or invalid for invoice " . $new_invoice_id . ". Email provided: '" . $customer_email_for_sending . "'");
                set_transient('xr_invoice_email_no_address_' . $new_invoice_id, true, 300);
            }
        }
        // --- End Optional Email Sending ---

        // Consider if you want to delete individual XML/PDF after zipping.
        // If email fails, or for archival, keeping them might be useful for a period.
        // Example:
        // if (file_exists($zip_file_path)) {
        //     @unlink($xml_file_path);
        //     @unlink($pdf_file_path);
        // }

        set_transient('xr_invoice_success_data', [
            'invoice_id' => $new_invoice_id,
            'zip_url' => $upload_dir['baseurl'] . "/invoices/invoice_{$new_invoice_id}.zip"
        ], 300); 

        // Redirect to the same page, but add a query arg to show success message
        $redirect_url = add_query_arg('invoice_generated', $new_invoice_id, wp_get_referer() ?: home_url());
        wp_safe_redirect($redirect_url);
        exit;

    } catch (Exception $e) {
        error_log('XRechnung Invoice generation error: ' . $e->getMessage());
        // Store the specific exception message to show to the user
        global $xr_form_submission_errors;
        $xr_form_submission_errors = [
            __('An error occurred while generating the invoice:', 'xrechnung'),
            $e->getMessage(), // Show the actual error from the exception
            __('Please check the PHP error log for more details or contact support.', 'xrechnung')
        ];
        // No redirect here, errors will be displayed above the form by xr_display_invoice_notifications
    }
}
// Hook earlier if needed, but template_redirect is usually fine for form processing before headers are sent.
add_action('template_redirect', 'xr_handle_invoice_form_submission', 5); // Lower priority to run earlier if needed

// This function displays notifications (errors or success)
function xr_display_invoice_notifications() {
    global $xr_form_submission_errors; 

    // Display errors from direct submission (if no redirect happened)
    if (!empty($xr_form_submission_errors)) {
        echo '<div class="invoice-notice error-notice"><ul>';
        foreach ($xr_form_submission_errors as $error) {
            echo '<li>' . esc_html($error) . '</li>';
        }
        echo '</ul></div>';
        $xr_form_submission_errors = []; // Clear after displaying
    }
    
    // Display errors from transient (after redirect)
    $errors_transient = get_transient('xr_invoice_form_errors');
    if ($errors_transient) {
        echo '<div class="invoice-notice error-notice"><ul>';
        foreach ($errors_transient as $error) {
            echo '<li>' . esc_html($error) . '</li>';
        }
        echo '</ul></div>';
        delete_transient('xr_invoice_form_errors');
    }

    // Display success message
    if (!empty($_GET['invoice_generated'])) {
        $invoice_id = sanitize_text_field($_GET['invoice_generated']);
        $success_data = get_transient('xr_invoice_success_data');

        if ($success_data && $success_data['invoice_id'] === $invoice_id) {
            echo '<div class="invoice-notice success-notice">';
            echo '<p>' . sprintf(__('Invoice %s generated successfully!', 'xrechnung'), esc_html($success_data['invoice_id'])) . '</p>';
            echo '<p><a href="' . esc_url($success_data['zip_url']) . '" class="button download-button" download>' . __('Download Invoice (ZIP)', 'xrechnung') . '</a></p>';
            
            // Display email status notices
            if (get_transient('xr_invoice_email_sent_' . $invoice_id)) {
                echo '<p>' . __('An email with the invoice has been sent to the customer.', 'xrechnung') . '</p>';
                delete_transient('xr_invoice_email_sent_' . $invoice_id);
            }
            if (get_transient('xr_invoice_email_failed_' . $invoice_id)) {
                echo '<p class="warning-notice">' . __('The invoice was generated, but there was an issue sending the email. Please check your mail server configuration or send the invoice manually.', 'xrechnung') . '</p>';
                delete_transient('xr_invoice_email_failed_' . $invoice_id);
            }
            if (get_transient('xr_invoice_email_no_address_' . $invoice_id)) {
                echo '<p class="info-notice">' . __('Email sending is enabled, but no valid customer email address was provided. The email was not sent.', 'xrechnung') . '</p>';
                delete_transient('xr_invoice_email_no_address_' . $invoice_id);
            }

            echo '</div>';
            delete_transient('xr_invoice_success_data');
        }
    }
}
// This needs to be hooked where it can output HTML before the shortcode,
// or the shortcode itself calls this function at its beginning.
// If the shortcode calls it directly, loop_start is not needed.
// add_action('loop_start', 'xr_display_invoice_notifications');