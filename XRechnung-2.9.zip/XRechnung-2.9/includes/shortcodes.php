<?php
defined('ABSPATH') || exit;

function xr_register_shortcodes() {
    add_shortcode('invoice_form', 'xr_invoice_form_shortcode');
}

function xr_invoice_form_shortcode() {
    ob_start();

    // Display any error or success messages first
    xr_display_invoice_notifications();


    $columns_config = get_option('xrechnung_columns', [
        ['key' => 'description', 'title' => __('Description', 'xrechnung'), 'required' => true],
        ['key' => 'quantity', 'title' => __('Quantity', 'xrechnung'), 'required' => true],
        ['key' => 'price', 'title' => __('Unit Price', 'xrechnung'), 'required' => true]
    ]);

    $currency_code = get_option('xrechnung_currency_code', 'EUR');

    $posted_data = [];
    if (!empty($_POST) && isset($_POST['xr_invoice_form_nonce'])) {
        $posted_data['customer_name'] = isset($_POST['customer_name']) ? stripslashes($_POST['customer_name']) : '';
        $posted_data['customer_email'] = isset($_POST['customer_email']) ? stripslashes($_POST['customer_email']) : '';
        $posted_data['customer_address'] = isset($_POST['customer_address']) ? stripslashes($_POST['customer_address']) : '';
        $posted_data['invoice_date'] = isset($_POST['invoice_date']) ? stripslashes($_POST['invoice_date']) : date('Y-m-d');
        $posted_data['subject'] = isset($_POST['subject']) ? stripslashes($_POST['subject']) : '';
        $posted_data['items'] = isset($_POST['items']) && is_array($_POST['items']) ? array_map('stripslashes_deep', $_POST['items']) : [];
    } else {
        $posted_data['invoice_date'] = date('Y-m-d');
    }

    ?>
    <div class="xr-invoice-form-container">
        <form method="post" id="xr-invoice-form" action="<?php echo esc_url(remove_query_arg('invoice_generated')); ?>">
            <?php wp_nonce_field('xr_generate_invoice_action', 'xr_invoice_form_nonce'); ?>

            <fieldset class="xr-customer-info">
                <legend><?php _e('Customer Information', 'xrechnung'); ?></legend>
                <p>
                    <label for="customer_name"><?php _e('Name:', 'xrechnung'); ?> <span class="required">*</span></label>
                    <input type="text" name="customer_name" id="customer_name" class="xr-form-input" value="<?php echo esc_attr($posted_data['customer_name'] ?? ''); ?>" required>
                </p>
                <p>
                    <label for="customer_email"><?php _e('Email:', 'xrechnung'); ?> <span class="required">*</span></label>
                    <input type="email" name="customer_email" id="customer_email" class="xr-form-input" value="<?php echo esc_attr($posted_data['customer_email'] ?? ''); ?>" required>
                </p>
                <p>
                    <label for="customer_address"><?php _e('Address:', 'xrechnung'); ?> <span class="required">*</span></label>
                    <textarea name="customer_address" id="customer_address" class="xr-form-input" rows="3" required><?php echo esc_textarea($posted_data['customer_address'] ?? ''); ?></textarea>
                </p>
            </fieldset>

            <fieldset class="xr-invoice-details">
                <legend><?php _e('Invoice Details', 'xrechnung'); ?></legend>
                 <p>
                    <label for="invoice_date"><?php _e('Invoice Date:', 'xrechnung'); ?> <span class="required">*</span></label>
                    <input type="date" name="invoice_date" id="invoice_date" class="xr-form-input" value="<?php echo esc_attr($posted_data['invoice_date']); ?>" required>
                </p>
                <p>
                    <label for="subject"><?php _e('Subject / Reference:', 'xrechnung'); ?> <span class="required">*</span></label>
                    <input type="text" name="subject" id="subject" class="xr-form-input" value="<?php echo esc_attr($posted_data['subject'] ?? ''); ?>" required>
                </p>
            </fieldset>

            <fieldset class="xr-items-info">
                <legend><?php _e('Invoice Items', 'xrechnung'); ?></legend>
                <div id="xr-items-container">
                    <?php
                    $items_to_display = !empty($posted_data['items']) ? $posted_data['items'] : [[]];
                    foreach ($items_to_display as $item_idx => $item_data):
                    ?>
                    <div class="xr-item-row">
                        <?php foreach ($columns_config as $col_config): ?>
                        <div class="xr-item-col xr-item-col-<?php echo esc_attr($col_config['key']); ?>">
                            <label for="items_<?php echo $item_idx; ?>_<?php echo esc_attr($col_config['key']); ?>">
                                <?php echo esc_html(__($col_config['title'], 'xrechnung')); ?>
                                <?php if ($col_config['required']) echo ' <span class="required">*</span>'; ?>
                            </label>
                            <input type="<?php echo ($col_config['key'] === 'price' || $col_config['key'] === 'quantity') ? 'number' : 'text'; ?>"
                                   name="items[<?php echo $item_idx; ?>][<?php echo esc_attr($col_config['key']); ?>]"
                                   id="items_<?php echo $item_idx; ?>_<?php echo esc_attr($col_config['key']); ?>"
                                   class="xr-form-input"
                                   value="<?php echo esc_attr($item_data[$col_config['key']] ?? ''); ?>"
                                   <?php if ($col_config['required']) echo 'required'; ?>
                                   <?php if ($col_config['key'] === 'price' || $col_config['key'] === 'quantity') echo 'step="0.01" min="0"'; ?>>
                        </div>
                        <?php endforeach; ?>
                        <div class="xr-item-col xr-item-col-actions">
                            <button type="button" class="button xr-remove-item" title="<?php esc_attr_e('Remove Item', 'xrechnung'); ?>">×</button>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <button type="button" id="xr-add-item" class="button button-secondary"><?php _e('+ Add Item', 'xrechnung'); ?></button>
            </fieldset>

            <fieldset class="xr-totals-summary">
                <legend><?php _e('Summary', 'xrechnung'); ?></legend>
                <p>
                    <label><?php _e('Subtotal:', 'xrechnung'); ?></label>
                    <span id="xr-subtotal-amount" class="xr-summary-amount">0.00</span> <?php echo esc_html($currency_code); ?>
                </p>
                <p>
                    <label><?php _e('VAT', 'xrechnung'); ?> (<span id="xr-vat-rate-display">0</span>%):</label>
                    <span id="xr-vat-amount" class="xr-summary-amount">0.00</span> <?php echo esc_html($currency_code); ?>
                </p>
                <p class="xr-grand-total">
                    <label><?php _e('Grand Total (Incl. Tax):', 'xrechnung'); ?></label>
                    <span id="xr-grand-total-amount" class="xr-summary-amount">0.00</span> <?php echo esc_html($currency_code); ?>
                </p>
                <input type="hidden" name="total_amount_incl_tax_calculated" id="total_amount_incl_tax_calculated" value="0">
            </fieldset>

            <p class="xr-submit-p">
                <button type="submit" name="generate_invoice_submit" id="generate_invoice_submit" class="button button-primary"><?php _e('Generate & Send Invoice', 'xrechnung'); ?></button>
            </p>
        </form>
    </div>
    <?php
    return ob_get_clean();
}