<?php
defined('ABSPATH') || exit;

// Create invoices directory on activation
function xr_create_invoices_directory() {
    $upload_dir = wp_upload_dir();
    $invoices_dir = $upload_dir['basedir'] . '/invoices';

    if (!file_exists($invoices_dir)) {
        if (!wp_mkdir_p($invoices_dir)) {
            error_log('Failed to create invoices directory: ' . $invoices_dir);
            return false;
        }
        // Add index.php to prevent directory listing
        file_put_contents($invoices_dir . '/index.php', '<?php // Silence is golden');
        // Add .htaccess to protect files if server allows
        $htaccess_content = "Options -Indexes\ndeny from all";
        file_put_contents($invoices_dir . '/.htaccess', $htaccess_content);
    }
    return true;
}

// Plugin activation function
function xr_activate_plugin() {
    if (get_option('xrechnung_send_email_to_customer') === false) {
    update_option('xrechnung_send_email_to_customer', 1); // Default to sending email
    }
    if (!xr_create_invoices_directory()) {
        // Optionally, prevent activation or notify admin
        add_action('admin_notices', function() {
            echo '<div class="error"><p>ZUGFeRD & XRechnung Invoice Generator: Failed to create required directory <code>wp-content/uploads/invoices/</code>. Please check server permissions.</p></div>';
        });
        // Deactivate if critical
        // deactivate_plugins(plugin_basename(XR_PLUGIN_DIR . 'zugferd-xrechnung-invoice-generator.php'));
        // wp_die('Failed to create required directories. Please check your server permissions and try again.');
    }

    // Set default options if not already set
    if (get_option('xrechnung_next_invoice_number') === false) {
        update_option('xrechnung_next_invoice_number', '1');
    }
    if (get_option('xrechnung_vat_rate') === false) {
        update_option('xrechnung_vat_rate', '19'); // Default VAT rate
    }
    if (get_option('xrechnung_currency_code') === false) {
        update_option('xrechnung_currency_code', 'EUR');
    }
     if (get_option('xrechnung_columns') === false) {
        update_option('xrechnung_columns', [
            ['key' => 'description', 'title' => __('Description', 'xrechnung'), 'required' => true],
            ['key' => 'quantity', 'title' => __('Quantity', 'xrechnung'), 'required' => true],
            ['key' => 'price', 'title' => __('Unit Price', 'xrechnung'), 'required' => true]
        ]);
    }
    if (get_option('xrechnung_language') === false) {
        update_option('xrechnung_language', 'en');
    }
    if (get_option('xrechnung_bank_info_type') === false) {
        update_option('xrechnung_bank_info_type', 'text');
    }
}