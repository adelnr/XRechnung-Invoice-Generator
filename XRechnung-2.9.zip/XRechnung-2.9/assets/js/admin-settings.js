jQuery(document).ready(function($) {
    // Media uploader for Logo
    $('#upload_logo_button').click(function(e) {
        e.preventDefault();
        var button = $(this);
        var image = wp.media({
            title: 'Upload Company Logo',
            multiple: false
        }).open()
        .on('select', function() {
            var uploaded_image = image.state().get('selection').first();
            var logo_url = uploaded_image.toJSON().url;
            $('#xrechnung_logo').val(logo_url);
            $('#logo_preview_wrapper').html('<img src="' + logo_url + '" style="max-width:200px; max-height:100px; border:1px solid #ddd;">');
        });
    });

    // Media uploader for Signature Image
    $('#upload_signature_button').click(function(e) {
        e.preventDefault();
        var button = $(this);
        var image = wp.media({
            title: 'Upload Signature Image',
            multiple: false
        }).open()
        .on('select', function() {
            var uploaded_image = image.state().get('selection').first();
            var image_url = uploaded_image.toJSON().url;
            $('#xrechnung_signature_image').val(image_url);
            $('#signature_preview_wrapper').html('<img src="' + image_url + '" style="max-width:200px; max-height:100px; border:1px solid #ddd;">');
        });
    });

    // Invoice Columns Manager
    var columnsContainer = $('#invoice-columns-container');
    
    function updateColumnIndexes() {
        columnsContainer.find('.column-row').each(function(rowIndex) {
            $(this).attr('data-index', rowIndex);
            $(this).find('input, select').each(function() {
                var name = $(this).attr('name');
                if (name) {
                    name = name.replace(/\[\d+\]/, '[' + rowIndex + ']');
                    $(this).attr('name', name);
                }
            });
        });
    }

    $('#add-column').on('click', function() {
        var newIndex = columnsContainer.find('.column-row').length;
        var newRow = $('<div class="column-row" data-index="' + newIndex + '">' +
            '<input type="text" name="xrechnung_columns[' + newIndex + '][key]" placeholder="Key (e.g., item_sku)" required pattern="[a-zA-Z0-9_\\-]+">' +
            '<input type="text" name="xrechnung_columns[' + newIndex + '][title]" placeholder="Title (e.g., Item SKU)" required>' +
            '<label><input type="checkbox" name="xrechnung_columns[' + newIndex + '][required]" value="1"> Required?</label>' +
            '<button type="button" class="button button-secondary remove-column">Remove</button>' +
            '</div>');
        columnsContainer.append(newRow);
        updateColumnIndexes(); // Should not be strictly necessary on add if newIndex is correct
    });

    columnsContainer.on('click', '.remove-column', function() {
        if (columnsContainer.find('.column-row').length > 1) { // Keep at least one
            $(this).closest('.column-row').remove();
            updateColumnIndexes();
        } else {
            alert('You must have at least one column.');
        }
    });

    // Initial call to set indexes correctly if loaded from saved options
    if (columnsContainer.length > 0) {
        updateColumnIndexes();
    }
});