<?php
defined('ABSPATH') || exit;

use Dompdf\Dompdf;
use Dompdf\Options;

// Get company logo URL (already sanitized from settings)
function xr_get_company_logo_url() {
    return get_option('xrechnung_logo', '');
}

// Get company info
function xr_get_company_info() {
    return [
        'name' => get_option('xrechnung_company_name', __('Your Company Name', 'xrechnung')),
        'address' => get_option('xrechnung_company_address', __('Your Company Address', 'xrechnung')),
        'phone' => get_option('xrechnung_company_phone', __('Your Company Phone', 'xrechnung')),
        'email' => get_option('xrechnung_company_email', __('Your Company Email', 'xrechnung')),
    ];
}

// Generate QR code for EPC (European Payments Council)
function xr_generate_epc_qr_code($amount, $invoice_id = '') {
    $iban = get_option('xrechnung_iban', '');
    $bic = get_option('xrechnung_bic', ''); // Optional for SEPA QR, but good to have
    $company_name = get_option('xrechnung_company_name', 'Your Company Name');
    $currency = get_option('xrechnung_currency_code', 'EUR');
    $remittance_info = $invoice_id ? __('Invoice', 'xrechnung') . ' ' . $invoice_id : '';


    if (empty($iban) || empty($company_name)) {
        return ''; // Not enough data for a valid QR code
    }

    $amount_formatted = number_format((float)$amount, 2, '.', '');
    $qr_data = "BCD\n002\n1\nSCT\n" .
               (!empty($bic) ? $bic : '') . "\n" .
               mb_substr($company_name, 0, 70) . "\n" . // Max 70 chars
               $iban . "\n" .
               $currency . $amount_formatted . "\n" .
               "\n" . // Purpose (empty)
               mb_substr($remittance_info, 0, 140) . "\n" . // Remittance info
               ""; // User hint (empty)

    return "https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=" . urlencode($qr_data);
}


// Generate invoice XML
function xr_generate_invoice_xml($data, $invoice_id) {
    $company_info = xr_get_company_info();
    $currency = get_option('xrechnung_currency_code', 'EUR');
    $vat_rate_percent = (float) get_option('xrechnung_vat_rate', 0);

    $xml = new SimpleXMLElement('<?xml version="1.0" encoding="UTF-8"?>
        <rsm:CrossIndustryInvoice xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                                   xmlns:rsm="urn:un:unece:uncefact:data:standard:CrossIndustryInvoice:100"
                                   xmlns:ram="urn:un:unece:uncefact:data:standard:ReusableAggregateBusinessInformationEntity:100"
                                   xmlns:udt="urn:un:unece:uncefact:data:standard:UnqualifiedDataType:100">
        </rsm:CrossIndustryInvoice>');

    // ExchangedDocumentContext
    $context = $xml->addChild('rsm:ExchangedDocumentContext');
    $context->addChild('ram:GuidelineSpecifiedDocumentContextParameter')
            ->addChild('ram:ID', 'urn:cen.eu:en16931:2017#compliant#urn:xoev-de:kosit:standard:xrechnung_2.1');

    // ExchangedDocument
    $doc = $xml->addChild('rsm:ExchangedDocument');
    $doc->addChild('ram:ID', $invoice_id);
    $doc->addChild('ram:TypeCode', '380');
    $doc->addChild('ram:IssueDateTime')
        ->addChild('udt:DateTimeString', date('Y-m-d\TH:i:s', strtotime($data['invoice_date'])))
        ->addAttribute('format', '102');

    if (!empty($data['subject'])) {
        $doc->addChild('ram:Name', htmlspecialchars($data['subject']));
    }
    
    $service_date_option = get_option('xrechnung_service_date', '');
    if(!empty($service_date_option)) {
        $doc->addChild('ram:IncludedNote')
            ->addChild('ram:Content', __('Service Date', 'xrechnung') . ': ' . htmlspecialchars($service_date_option));
    }

    // SupplyChainTradeTransaction
    $trade = $xml->addChild('rsm:SupplyChainTradeTransaction');

    // ApplicableHeaderTradeAgreement node that will hold both Seller and Buyer
    $headerTradeAgreement = $trade->addChild('ram:ApplicableHeaderTradeAgreement');

    // SellerTradeParty (Your Company)
    $seller = $headerTradeAgreement->addChild('ram:SellerTradeParty');
    $seller->addChild('ram:Name', htmlspecialchars($company_info['name']));
    $sellerPostal = $seller->addChild('ram:PostalTradeAddress');
    $sellerPostal->addChild('ram:LineOne', htmlspecialchars($company_info['address']));
    // $sellerPostal->addChild('ram:CountryID', 'DE'); // Example

    $sellerContact = $seller->addChild('ram:DefinedTradeContact');
    if (!empty($company_info['phone'])) {
        $sellerContact->addChild('ram:TelephoneUniversalCommunication')
                      ->addChild('ram:CompleteNumber', htmlspecialchars($company_info['phone']));
    }
    if (!empty($company_info['email'])) {
        $sellerContact->addChild('ram:EmailURIUniversalCommunication')
                      ->addChild('ram:URIID', htmlspecialchars($company_info['email']));
    }
    // $seller->addChild('ram:SpecifiedTaxRegistration')->addChild('ram:ID', 'YOUR_VAT_ID')->addAttribute('schemeID', 'VA');

    // BuyerTradeParty (Customer)
    // Add BuyerTradeParty to the SAME ApplicableHeaderTradeAgreement as the Seller
    $buyer = $headerTradeAgreement->addChild('ram:BuyerTradeParty'); // CORRECTED LINE
    $buyer->addChild('ram:Name', htmlspecialchars($data['customer_name']));
    $buyerPostal = $buyer->addChild('ram:PostalTradeAddress');
    $buyerPostal->addChild('ram:LineOne', htmlspecialchars($data['customer_address']));
    // $buyerPostal->addChild('ram:CountryID', 'CUSTOMER_COUNTRY_CODE'); // Example
    if(!empty($data['customer_email'])){
         $buyerContact = $buyer->addChild('ram:DefinedTradeContact'); // Add contact under buyer if email exists
         $buyerContact->addChild('ram:EmailURIUniversalCommunication')
                      ->addChild('ram:URIID', htmlspecialchars($data['customer_email']));
    }


    // ApplicableHeaderTradeSettlement
    $settlement = $trade->addChild('ram:ApplicableHeaderTradeSettlement');
    $settlement->addChild('ram:InvoiceCurrencyCode', $currency);

    // Monetary Summation
    $monetarySummation = $settlement->addChild('ram:SpecifiedTradeSettlementHeaderMonetarySummation');
    $monetarySummation->addChild('ram:LineTotalAmount', xr_format_number($data['total_amount_excl_tax']))->addAttribute('currencyID', $currency);
    $monetarySummation->addChild('ram:TaxBasisTotalAmount', xr_format_number($data['total_amount_excl_tax']))->addAttribute('currencyID', $currency);
    $monetarySummation->addChild('ram:TaxTotalAmount', xr_format_number($data['vat_amount']))->addAttribute('currencyID', $currency);
    $monetarySummation->addChild('ram:GrandTotalAmount', xr_format_number($data['total_amount_incl_tax']))->addAttribute('currencyID', $currency);
    $monetarySummation->addChild('ram:DuePayableAmount', xr_format_number($data['total_amount_incl_tax']))->addAttribute('currencyID', $currency);

    // VAT Breakdown (ApplicableTradeTax)
    if ($vat_rate_percent > 0 && $data['vat_amount'] > 0) {
        $tradeTax = $settlement->addChild('ram:ApplicableTradeTax');
        $tradeTax->addChild('ram:CalculatedAmount', xr_format_number($data['vat_amount']))->addAttribute('currencyID', $currency);
        $tradeTax->addChild('ram:TypeCode', 'VAT');
        $tradeTax->addChild('ram:BasisAmount', xr_format_number($data['total_amount_excl_tax']))->addAttribute('currencyID', $currency);
        $tradeTax->addChild('ram:CategoryCode', 'S');
        $tradeTax->addChild('ram:RateApplicablePercent', xr_format_number($vat_rate_percent));
    }


    // IncludedSupplyChainTradeLineItem
    foreach ($data['items'] as $index => $item) {
        $line_item_total_excl_tax = (float)$item['price'] * (float)$item['quantity'];
        // $line_item_vat_amount = $line_item_total_excl_tax * ($vat_rate_percent / 100); // Not directly used here

        $lineItem = $trade->addChild('ram:IncludedSupplyChainTradeLineItem');
        $lineDoc = $lineItem->addChild('ram:AssociatedDocumentLineDocument');
        $lineDoc->addChild('ram:LineID', $index + 1);

        $product = $lineItem->addChild('ram:SpecifiedTradeProduct');
        $product->addChild('ram:Name', htmlspecialchars($item['description']));

        // SpecifiedLineTradeSettlement for line item
        $lineSettlement = $lineItem->addChild('ram:SpecifiedLineTradeSettlement');

        // ClassifiedTaxCategory for line item VAT (within SpecifiedLineTradeSettlement)
        if ($vat_rate_percent > 0) {
            $lineTradeTax = $lineSettlement->addChild('ram:ApplicableTradeTax'); // Correctly placed
            $lineTradeTax->addChild('ram:TypeCode', 'VAT');
            $lineTradeTax->addChild('ram:CategoryCode', 'S');
            $lineTradeTax->addChild('ram:RateApplicablePercent', xr_format_number($vat_rate_percent));
        }

        $lineAgreement = $lineItem->addChild('ram:SpecifiedLineTradeAgreement');
        $grossPrice = $lineAgreement->addChild('ram:GrossPriceProductTradePrice'); // This is net price before item VAT for XRechnung
        $grossPrice->addChild('ram:ChargeAmount', xr_format_number($item['price']))->addAttribute('currencyID', $currency);
        // $grossPrice->addChild('ram:BasisQuantity', '1.00')->addAttribute('unitCode', 'C62');

        $lineDelivery = $lineItem->addChild('ram:SpecifiedLineTradeDelivery');
        $lineDelivery->addChild('ram:BilledQuantity', xr_format_number($item['quantity']))->addAttribute('unitCode', 'C62');

        $lineMonetarySummation = $lineSettlement->addChild('ram:SpecifiedTradeSettlementLineMonetarySummation');
        $lineMonetarySummation->addChild('ram:LineTotalAmount', xr_format_number($line_item_total_excl_tax))->addAttribute('currencyID', $currency);
    }

    $dom = new DOMDocument('1.0');
    $dom->preserveWhiteSpace = false;
    $dom->formatOutput = true;
    $dom->loadXML($xml->asXML());
    return $dom->saveXML();
}

// Helper to format numbers for XML
function xr_format_number($number, $decimals = 2) {
    return number_format((float)$number, $decimals, '.', '');
}

// Generate invoice PDF
function xr_generate_invoice_pdf($data, $invoice_id) {
    $upload_dir = wp_upload_dir();
    $file_path = $upload_dir['basedir'] . "/invoices/invoice_{$invoice_id}.pdf";

    $company_logo_url = xr_get_company_logo_url();
    $company_info = xr_get_company_info();
    $currency = get_option('xrechnung_currency_code', 'EUR');
    $vat_rate_percent = (float) get_option('xrechnung_vat_rate', 0);

    $language = get_option('xrechnung_language', 'en');
    $intro_text = get_option('xrechnung_intro_text', '');
    $footer_text = get_option('xrechnung_footer_text', '');
    $signature_name = get_option('xrechnung_signature_name', '');
    $signature_title = get_option('xrechnung_signature_title', '');
    $signature_image_url = get_option('xrechnung_signature_image', '');
    $bank_info_type = get_option('xrechnung_bank_info_type', 'text');
    $iban = get_option('xrechnung_iban', '');
    $bic = get_option('xrechnung_bic', '');
    $service_date_option = get_option('xrechnung_service_date', '');

    $t_common = [
        'invoice' => __('Invoice', 'xrechnung'),
        'from' => __('From', 'xrechnung'),
        'to' => __('To', 'xrechnung'),
        'subject' => __('Subject', 'xrechnung'),
        'service_date' => __('Service Date', 'xrechnung'),
        'invoice_date' => __('Invoice Date', 'xrechnung'),
        'invoice_number' => __('Invoice Number', 'xrechnung'),
        'bank_details' => __('Bank Details', 'xrechnung'),
        'pos' => __('Pos.', 'xrechnung'),
        'description' => __('Description', 'xrechnung'),
        'quantity' => __('Quantity', 'xrechnung'),
        'unit_price' => sprintf(__('Unit Price (%s)', 'xrechnung'), $currency),
        'total_line' => sprintf(__('Total (%s)', 'xrechnung'), $currency),
        'subtotal' => sprintf(__('Subtotal (%s)', 'xrechnung'), $currency),
        'vat_rate' => sprintf(__('VAT (%s%%)', 'xrechnung'), xr_format_number($vat_rate_percent)),
        'vat_amount' => sprintf(__('VAT Amount (%s)', 'xrechnung'), $currency),
        'grand_total' => sprintf(__('Grand Total (%s)', 'xrechnung'), $currency),
    ];
    $t = $t_common;


    $qr_code_image_base64 = '';
    if ($bank_info_type === 'qr' && !empty($iban)) {
        $qr_code_url = xr_generate_epc_qr_code($data['total_amount_incl_tax'], $invoice_id);
        if ($qr_code_url) {
            $qr_contents = @file_get_contents($qr_code_url); // Use @ to suppress warnings on failure
            if ($qr_contents) {
                $qr_code_image_base64 = base64_encode($qr_contents);
            } else {
                error_log("XRechnung Plugin: Failed to fetch QR code from URL: " . $qr_code_url);
            }
        }
    }

    $logo_image_base64 = '';
    if ($company_logo_url) {
        $logo_path = xr_get_path_from_url($company_logo_url);
        if ($logo_path && file_exists($logo_path) && is_readable($logo_path)) {
            $logo_contents = file_get_contents($logo_path);
            if ($logo_contents) {
                $logo_image_base64 = base64_encode($logo_contents);
                $logo_mime_type = mime_content_type($logo_path);
            }
        } else {
             error_log("XRechnung Plugin: Company logo not found or not readable at path: " . $logo_path . " (from URL: " . $company_logo_url . ")");
        }
    }
    
    $signature_image_base64 = '';
    if ($signature_image_url) {
        $sig_path = xr_get_path_from_url($signature_image_url);
        if ($sig_path && file_exists($sig_path) && is_readable($sig_path)) {
            $sig_contents = file_get_contents($sig_path);
            if ($sig_contents) {
                $signature_image_base64 = base64_encode($sig_contents);
                $sig_mime_type = mime_content_type($sig_path);
            }
        } else {
            error_log("XRechnung Plugin: Signature image not found or not readable at path: " . $sig_path . " (from URL: " . $signature_image_url . ")");
        }
    }


    $pdf_css_path = XR_PLUGIN_DIR . 'assets/css/invoice-pdf.css';
    $pdf_css = '';
    if(file_exists($pdf_css_path) && is_readable($pdf_css_path)){
        $pdf_css = file_get_contents($pdf_css_path);
    } else {
        error_log("XRechnung Plugin: PDF CSS file not found or not readable at: " . $pdf_css_path);
    }
    
    $columns_config = get_option('xrechnung_columns', []);

    $html = "<!DOCTYPE html><html lang='{$language}'><head><meta charset='UTF-8'><title>{$t['invoice']} {$invoice_id}</title><style>{$pdf_css}</style></head><body>";
    $html .= '<div class="invoice-wrapper">'; 

    $html .= '<div class="invoice">';
    $html .= '<header class="header section-avoid-break">';
    if ($logo_image_base64 && isset($logo_mime_type)) {
        $html .= '<div class="logo-container"><img src="data:' . esc_attr($logo_mime_type) . ';base64,' . $logo_image_base64 . '" alt="' . esc_attr__('Company Logo', 'xrechnung') . '"></div>';
    }
    $html .= '<div class="invoice-title-details">';
    $html .= '<h1>' . esc_html($t['invoice']) . '</h1>';
    if (!empty($service_date_option)) {
        $html .= '<p><strong>' . esc_html($t['service_date']) . ':</strong> ' . esc_html(date_i18n(get_option('date_format'), strtotime($service_date_option))) . '</p>';
    }
    $html .= '<p><strong>' . esc_html($t['invoice_date']) . ':</strong> ' . esc_html(date_i18n(get_option('date_format'), strtotime($data['invoice_date']))) . '</p>';
    $html .= '<p><strong>' . esc_html($t['invoice_number']) . ':</strong> ' . esc_html($invoice_id) . '</p>';
    $html .= '</div></header>';

    $html .= '<section class="addresses section-avoid-break">';
    $html .= '<div class="from-address"><h3>' . esc_html($t['from']) . '</h3><p>' . nl2br(esc_html($company_info['name'])) . '</p><p>' . nl2br(esc_html($company_info['address'])) . '</p>';
    if($company_info['phone']) $html .= '<p>' . __('Phone:', 'xrechnung') . ' ' . esc_html($company_info['phone']) . '</p>';
    if($company_info['email']) $html .= '<p>' . __('Email:', 'xrechnung') . ' ' . esc_html($company_info['email']) . '</p>';
    $html .= '</div>';
    $html .= '<div class="to-address"><h3>' . esc_html($t['to']) . '</h3><p>' . nl2br(esc_html($data['customer_name'])) . '</p><p>' . nl2br(esc_html($data['customer_address'])) . '</p>';
    if($data['customer_email']) $html .= '<p>' . __('Email:', 'xrechnung') . ' ' . esc_html($data['customer_email']) . '</p>';
    $html .= '</div></section>';

    if (!empty($intro_text)) {
        $html .= '<section class="intro-text section-avoid-break"><p>' . nl2br(esc_html($intro_text)) . '</p></section>';
    }
    if (!empty($data['subject'])) {
         $html .= '<section class="subject-text section-avoid-break"><p><strong>' . esc_html($t['subject']) . ':</strong> ' . esc_html($data['subject']) . '</p></section>';
    }


    $html .= '<section class="items-table section-avoid-break"><table><thead><tr>';
    $html .= '<th>' . esc_html($t['pos']) . '</th>';
    foreach ($columns_config as $col_config) {
         $html .= '<th>' . esc_html(__($col_config['title'], 'xrechnung')) . '</th>';
    }
    $html .= '<th>' . esc_html($t['total_line']) . '</th>';
    $html .= '</tr></thead><tbody>';

    foreach ($data['items'] as $index => $item) {
        $line_total = (float)$item['price'] * (float)$item['quantity'];
        $html .= '<tr><td>' . ($index + 1) . '</td>';
        foreach ($columns_config as $col_config) {
            $item_value = isset($item[$col_config['key']]) ? $item[$col_config['key']] : '';
            if ($col_config['key'] === 'price') {
                $item_value = xr_format_number($item_value);
            }
             if ($col_config['key'] === 'quantity') {
                $item_value = xr_format_number($item_value, 2); 
            }
            $html .= '<td>' . esc_html($item_value) . '</td>';
        }
        $html .= '<td class="amount">' . xr_format_number($line_total) . '</td></tr>';
    }
    $html .= '</tbody></table></section>';

    $html .= '<section class="totals section-avoid-break"><table>';
    $html .= '<tr><td>' . esc_html($t['subtotal']) . '</td><td class="amount">' . xr_format_number($data['total_amount_excl_tax']) . '</td></tr>';
    if ($vat_rate_percent > 0) {
        $html .= '<tr><td>' . esc_html($t['vat_rate']) . '</td><td class="amount">' . xr_format_number($data['vat_amount']) . '</td></tr>';
    }
    $html .= '<tr class="grand-total"><td>' . esc_html($t['grand_total']) . '</td><td class="amount">' . xr_format_number($data['total_amount_incl_tax']) . '</td></tr>';
    $html .= '</table></section>';


    $html .= '<footer class="footer-section section-avoid-break">';
    if ($bank_info_type === 'qr' && $qr_code_image_base64) {
        $html .= '<div class="bank-details qr-code-payment"><img src="data:image/png;base64,' . $qr_code_image_base64 . '" alt="' . esc_attr__('EPC QR Code for Payment', 'xrechnung') . '"></div>';
    } elseif ($bank_info_type === 'text' && !empty($iban)) {
        $html .= '<div class="bank-details"><p><strong>' . esc_html($t['bank_details']) . ':</strong></p>';
        $html .= '<p>' . __('IBAN:', 'xrechnung') . ' ' . esc_html($iban) . '</p>';
        if (!empty($bic)) {
            $html .= '<p>' . __('BIC:', 'xrechnung') . ' ' . esc_html($bic) . '</p>';
        }
        $html .= '</div>';
    }

    if ($signature_image_base64 && isset($sig_mime_type)) {
        $html .= '<div class="signature">';
        $html .= '<img src="data:' . esc_attr($sig_mime_type) . ';base64,' . $signature_image_base64 . '" alt="' . esc_attr__('Signature', 'xrechnung') . '">';
        if (!empty($signature_name) || !empty($signature_title)) {
            $html .= '<div>';
            if (!empty($signature_name)) $html .= '<p>' . esc_html($signature_name) . '</p>';
            if (!empty($signature_title)) $html .= '<p><em>' . esc_html($signature_title) . '</em></p>';
            $html .= '</div>';
        }
        $html .= '</div>';
    }

    if (!empty($footer_text)) {
        $html .= '<div class="footer-text"><p>' . nl2br(esc_html($footer_text)) . '</p></div>';
    }
    $html .= '</footer>'; 

    $html .= '</div>'; 
    $html .= '</div>'; 
    $html .= '</body></html>';

    try {
        $options = new Options();
        $options->set('isRemoteEnabled', true); 
        $options->set('isHtml5ParserEnabled', true);
        $options->set('defaultFont', 'DejaVu Sans'); 
        // For debugging PDF issues:
        // $options->set('debugPng', true);
        // $options->set('debugLayout', true);
        // $options->set('debugCss', true);

        $dompdf = new Dompdf($options);
        @$dompdf->loadHtml($html); // Use @ to suppress warnings during load if HTML is complex
        $dompdf->setPaper('A4', 'portrait');
        $dompdf->render();
        
        if(!file_put_contents($file_path, $dompdf->output())){
             error_log("XRechnung Plugin: Failed to write PDF to: " . $file_path);
             return false;
        }
        return $file_path;

    } catch (Exception $e) {
        error_log('XRechnung Plugin Dompdf Exception: ' . $e->getMessage() . ' --- HTML attempted (first 1000 chars): ' . substr(preg_replace('/\s+/', ' ', $html), 0, 1000) );
        return false;
    }
}

// Helper to get local path from URL (basic)
function xr_get_path_from_url($url) {
    $upload_dir = wp_upload_dir();
    // Check if URL is within uploads directory
    if (strpos($url, $upload_dir['baseurl']) === 0) {
        $path = $upload_dir['basedir'] . str_replace($upload_dir['baseurl'], '', $url);
        return realpath($path); // Resolve symbolic links and '..'
    }
    // Check if URL is absolute path already (less common but possible)
    if (strpos($url, $upload_dir['basedir']) === 0 && file_exists($url)) {
        return realpath($url);
    }

    // Attempt to convert any WP content URL to path
    $content_url = content_url();
    if (strpos($url, $content_url) === 0) {
        $path = WP_CONTENT_DIR . str_replace($content_url, '', $url);
        return realpath($path);
    }
    
    // Log if path cannot be determined
    // error_log("XRechnung Plugin: Could not determine local path for URL: " . $url);
    return false;
}